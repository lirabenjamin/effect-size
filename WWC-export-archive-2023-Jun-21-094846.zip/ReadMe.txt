Special characters in citations can cause Excel to display the data in the exported files incorrectly.
In order to have the data display correctly please open the exported files in NotePad or follow the directions below when importing the files to Excel.

1. Open a new workbook in Excel
2. PC: Select the “Data” tab of the menu, then select “From Text” in the section entitled “Get External Data”
   Mac: Select “Import” from the “File” menu
3. In the window that opens, navigate to and select the csv file to import
4. In the “Text Import Wizard – Step 1 of 3” window, select “Delimited” and next to “File Origin” select “65001 : Unicode (UTF-8)”
5. Select “Next” at the bottom of the window
6. In the “Text Import Wizard – Step 2 of 3” window, put a checkmark next to “Comma” in the “Delimeters” box
7. Select “Finish” at the bottom of the window
8. In the “Import Data” window, select “OK”
